package Class03;

public class GCD {
    /**
     * Tìm UCLN của 2 số bằng thuật toán Euclid (đệ quy)
     *
     * @param a, b là hai số tự nhiên
     * @return UCLN của a và b
     */
    public int findGcdRecursive(int a, int b) {
        // TODO
        return 0;
    }

    /**
     * Tìm UCLN của 2 số bằng thuật toán Euclid(lặp)
     *
     * @param a, b là hai số tự nhiên
     * @return UCLN của a và b
     */
    public int findGcdIterative(int a, int b) {
        // TODO
        return 0;
    }

}
